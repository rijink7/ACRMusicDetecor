Cordova Plugin for ACR Cloud Music Recognition 

usage example:

ionic

ionic cordova plugin add https://github.com/rijink7/ACRMusicDetecor.git 
